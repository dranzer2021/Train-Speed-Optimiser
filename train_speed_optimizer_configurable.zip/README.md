# Configurable train speed-profile optimiser

## Files
- `train_speed_optimizer.py`: optimisation algorithm.
- `config.json`: train, route, timetable and engineering inputs.
- `result.json`: created when the program runs.

## Install and run
```bash
pip install numpy scipy matplotlib
python train_speed_optimizer.py --config config.json --output result.json --plot
```
`--plot` is optional.

## Editing the route inputs
All ranges are in kilometres, with `from_km` inclusive and `to_km` exclusive:
```json
"speed_restrictions": [
  {"from_km": 10.0, "to_km": 14.5, "speed_kmh": 80}
],
"gradients": [
  {"from_km": 40.0, "to_km": 52.0, "gradient_permille": 4.0},
  {"from_km": 52.0, "to_km": 60.0, "gradient_permille": -3.0}
],
"curves": [
  {"from_km": 72.0, "to_km": 73.2, "degree": 2.0}
]
```
The example ranges above are illustrative only; they are NOT actual HWH–NDLS route engineering data. Empty arrays in the supplied configuration mean no segment data has been provided, so only the configured train maximum line speed applies and the route is treated as level/straight where data is absent.

## Curve model
For a nonzero curve degree D, the configured approximation is:
`radius_m = curve_radius_constant_m_degree / D`
and the lateral-acceleration speed limit is:
`curve_speed_mps = sqrt(curve_lateral_accel_mps2 * radius_m)`.
The default constant is 1750 m-degree. Confirm the applicable degree-of-curve definition and actual curve radii/superelevation with the railway's engineering data before using this for any real route. This simplified curve limit does not explicitly model cant deficiency, transition curves, vehicle-specific limits or track condition.

## Timetable
The optimiser treats each listed station as a mandatory stop (speed = 0 at its chainage). Each leg's target running time is calculated from the previous station's departure to the next station's arrival. Overnight times are handled by rolling the next arrival into the next day if needed. Scheduled dwell time is therefore not counted as running time.

## Important modelling notes
- `rotating_mass_factor` is a multiplier. The supplied 1.08 means effective mass = total mass × 1.08.
- `max_power_kw` is treated as maximum wheel traction power, consistent with the supplied description.
- The algorithm imposes each timetable leg time as an equality. Real timetable feasibility is not guaranteed. If the schedule cannot be met within speed, force and acceleration constraints, SLSQP may fail or return an invalid candidate.
- The node speed bound uses the lower speed limit of adjacent intervals. This helps apply segment limits at boundary nodes, but this remains a discretised approximation.
- This is a research prototype, not a certified train-protection, signalling, braking-distance or railway operations system. Validate all results with railway engineering and safety specialists.
